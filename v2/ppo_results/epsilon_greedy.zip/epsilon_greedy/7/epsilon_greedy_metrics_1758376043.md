
---
# 📊 Informe Completo: Epsilon Greedy Agent
## Primer Pokémon obtenido (Interrumpido por usuario)

### 🎯 **Rendimiento Principal**
- **Recompensa Total:** `52.60`
- **Recompensa Máxima:** `52.60`
- **Recompensa Mínima:** `-0.05`
- **Recompensa Promedio/Paso:** `0.0022`
- **Pasos Totales:** `23,611`
- **Escenario:** Primer Pokémon obtenido (Interrumpido por usuario)

### ⏱️ **Análisis Temporal**
- **Tiempo Total:** `1586.10` segundos (26.44 minutos)
- **Pasos por Segundo:** `14.89`
- **Tiempo Promedio/Paso:** `67.18` ms

### 🧠 **Uso de Heurísticas**
- **Exploración:** 0 veces (0.0%)
- **Combate:** 0 veces (0.0%)
- **Menús:** 0 veces (0.0%)
- **Mundo Abierto:** 0 veces (0.0%)
- **Inicio:** 0 veces (0.0%)

### 🎮 **Detección de Escenarios**
- **Exploración:** 0 detecciones
- **Combate:** 0 detecciones
- **Menús:** 0 detecciones
- **Mundo Abierto:** 0 detecciones
- **Inicio:** 0 detecciones

### 💻 **Uso de Recursos del Sistema**
- **Memoria Actual:** `198.92` MB
- **Memoria Promedio:** `180.26` MB
- **CPU Actual:** `0.0%`
- **Posiciones Únicas Visitadas:** 1

### 📈 **Estadísticas de Acciones**
- **Total de Acciones:** 23,611
- **Distribución de Acciones:** {'A': 14186, '→': 2308, '↓': 2277, '↑': 2275, '←': 2271, 'B': 294, 'START': 0}

### 🔧 **Configuración del Agente**
- **Algoritmo:** Epsilon Greedy con Heurísticas
- **Epsilon Inicial:** Variable según escenario
- **Tiempo de Entrenamiento:** 0s (sin entrenamiento previo)
- **Versión del Entorno:** Pokemon Red v2

### 📝 **Notas Adicionales**
- Generado automáticamente el 2025-09-20 10:47:23
- Sesión ID: 1758376043
- Razón de finalización: Interrumpido por usuario

---
