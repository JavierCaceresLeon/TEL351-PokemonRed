
---
# 📊 Informe Completo: Epsilon Greedy Agent
## Primer Pokémon obtenido (Interrumpido por usuario)

### 🎯 **Rendimiento Principal**
- **Recompensa Total:** `51.20`
- **Recompensa Máxima:** `51.20`
- **Recompensa Mínima:** `-0.05`
- **Recompensa Promedio/Paso:** `0.0016`
- **Pasos Totales:** `31,546`
- **Escenario:** Primer Pokémon obtenido (Interrumpido por usuario)

### ⏱️ **Análisis Temporal**
- **Tiempo Total:** `2138.94` segundos (35.65 minutos)
- **Pasos por Segundo:** `14.75`
- **Tiempo Promedio/Paso:** `67.80` ms

### 🧠 **Uso de Heurísticas**
- **Exploración:** 0 veces (0.0%)
- **Combate:** 0 veces (0.0%)
- **Menús:** 0 veces (0.0%)
- **Mundo Abierto:** 0 veces (0.0%)
- **Inicio:** 0 veces (0.0%)

### 🎮 **Detección de Escenarios**
- **Exploración:** 0 detecciones
- **Combate:** 0 detecciones
- **Menús:** 0 detecciones
- **Mundo Abierto:** 0 detecciones
- **Inicio:** 0 detecciones

### 💻 **Uso de Recursos del Sistema**
- **Memoria Actual:** `215.87` MB
- **Memoria Promedio:** `187.40` MB
- **CPU Actual:** `0.0%`
- **Posiciones Únicas Visitadas:** 1

### 📈 **Estadísticas de Acciones**
- **Total de Acciones:** 31,546
- **Distribución de Acciones:** {'A': 18920, '←': 3118, '↓': 3117, '→': 3025, '↑': 3013, 'B': 353, 'START': 0}

### 🔧 **Configuración del Agente**
- **Algoritmo:** Epsilon Greedy con Heurísticas
- **Epsilon Inicial:** Variable según escenario
- **Tiempo de Entrenamiento:** 0s (sin entrenamiento previo)
- **Versión del Entorno:** Pokemon Red v2

### 📝 **Notas Adicionales**
- Generado automáticamente el 2025-09-20 11:23:23
- Sesión ID: 1758378203
- Razón de finalización: Interrumpido por usuario

---
