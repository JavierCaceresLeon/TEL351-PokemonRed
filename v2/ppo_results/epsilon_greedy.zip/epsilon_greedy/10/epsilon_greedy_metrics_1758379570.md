
---
# 📊 Informe Completo: Epsilon Greedy Agent
## Primer Pokémon obtenido (Interrumpido por usuario)

### 🎯 **Rendimiento Principal**
- **Recompensa Total:** `49.30`
- **Recompensa Máxima:** `49.30`
- **Recompensa Mínima:** `-0.05`
- **Recompensa Promedio/Paso:** `0.0033`
- **Pasos Totales:** `14,744`
- **Escenario:** Primer Pokémon obtenido (Interrumpido por usuario)

### ⏱️ **Análisis Temporal**
- **Tiempo Total:** `991.75` segundos (16.53 minutos)
- **Pasos por Segundo:** `14.87`
- **Tiempo Promedio/Paso:** `67.26` ms

### 🧠 **Uso de Heurísticas**
- **Exploración:** 0 veces (0.0%)
- **Combate:** 0 veces (0.0%)
- **Menús:** 0 veces (0.0%)
- **Mundo Abierto:** 0 veces (0.0%)
- **Inicio:** 0 veces (0.0%)

### 🎮 **Detección de Escenarios**
- **Exploración:** 0 detecciones
- **Combate:** 0 detecciones
- **Menús:** 0 detecciones
- **Mundo Abierto:** 0 detecciones
- **Inicio:** 0 detecciones

### 💻 **Uso de Recursos del Sistema**
- **Memoria Actual:** `188.37` MB
- **Memoria Promedio:** `175.92` MB
- **CPU Actual:** `0.0%`
- **Posiciones Únicas Visitadas:** 1

### 📈 **Estadísticas de Acciones**
- **Total de Acciones:** 14,744
- **Distribución de Acciones:** {'A': 8742, '→': 1482, '↓': 1464, '←': 1447, '↑': 1415, 'B': 194, 'START': 0}

### 🔧 **Configuración del Agente**
- **Algoritmo:** Epsilon Greedy con Heurísticas
- **Epsilon Inicial:** Variable según escenario
- **Tiempo de Entrenamiento:** 0s (sin entrenamiento previo)
- **Versión del Entorno:** Pokemon Red v2

### 📝 **Notas Adicionales**
- Generado automáticamente el 2025-09-20 11:46:10
- Sesión ID: 1758379570
- Razón de finalización: Interrumpido por usuario

---
