
---
# 📊 Informe Completo: Epsilon Greedy Agent
## Primer Pokémon obtenido (Interrumpido por usuario)

### 🎯 **Rendimiento Principal**
- **Recompensa Total:** `34.10`
- **Recompensa Máxima:** `34.10`
- **Recompensa Mínima:** `-0.05`
- **Recompensa Promedio/Paso:** `0.0075`
- **Pasos Totales:** `4,535`
- **Escenario:** Primer Pokémon obtenido (Interrumpido por usuario)

### ⏱️ **Análisis Temporal**
- **Tiempo Total:** `307.78` segundos (5.13 minutos)
- **Pasos por Segundo:** `14.73`
- **Tiempo Promedio/Paso:** `67.87` ms

### 🧠 **Uso de Heurísticas**
- **Exploración:** 0 veces (0.0%)
- **Combate:** 0 veces (0.0%)
- **Menús:** 0 veces (0.0%)
- **Mundo Abierto:** 0 veces (0.0%)
- **Inicio:** 0 veces (0.0%)

### 🎮 **Detección de Escenarios**
- **Exploración:** 0 detecciones
- **Combate:** 0 detecciones
- **Menús:** 0 detecciones
- **Mundo Abierto:** 0 detecciones
- **Inicio:** 0 detecciones

### 💻 **Uso de Recursos del Sistema**
- **Memoria Actual:** `171.64` MB
- **Memoria Promedio:** `165.44` MB
- **CPU Actual:** `0.0%`
- **Posiciones Únicas Visitadas:** 1

### 📈 **Estadísticas de Acciones**
- **Total de Acciones:** 4,535
- **Distribución de Acciones:** {'A': 2546, '←': 499, '↓': 464, '→': 453, '↑': 446, 'B': 127, 'START': 0}

### 🔧 **Configuración del Agente**
- **Algoritmo:** Epsilon Greedy con Heurísticas
- **Epsilon Inicial:** Variable según escenario
- **Tiempo de Entrenamiento:** 0s (sin entrenamiento previo)
- **Versión del Entorno:** Pokemon Red v2

### 📝 **Notas Adicionales**
- Generado automáticamente el 2025-09-20 11:28:53
- Sesión ID: 1758378533
- Razón de finalización: Interrumpido por usuario

---
