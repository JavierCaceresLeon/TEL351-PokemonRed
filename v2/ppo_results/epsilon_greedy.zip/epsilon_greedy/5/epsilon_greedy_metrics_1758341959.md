
---
# 📊 Informe Completo: Epsilon Greedy Agent
## Primer Pokémon obtenido (Interrumpido por usuario)

### 🎯 **Rendimiento Principal**
- **Recompensa Total:** `45.00`
- **Recompensa Máxima:** `45.00`
- **Recompensa Mínima:** `0.00`
- **Recompensa Promedio/Paso:** `0.0064`
- **Pasos Totales:** `6,991`
- **Escenario:** Primer Pokémon obtenido (Interrumpido por usuario)

### ⏱️ **Análisis Temporal**
- **Tiempo Total:** `470.01` segundos (7.83 minutos)
- **Pasos por Segundo:** `14.87`
- **Tiempo Promedio/Paso:** `67.23` ms

### 🧠 **Uso de Heurísticas**
- **Exploración:** 0 veces (0.0%)
- **Combate:** 0 veces (0.0%)
- **Menús:** 0 veces (0.0%)
- **Mundo Abierto:** 0 veces (0.0%)
- **Inicio:** 0 veces (0.0%)

### 🎮 **Detección de Escenarios**
- **Exploración:** 0 detecciones
- **Combate:** 0 detecciones
- **Menús:** 0 detecciones
- **Mundo Abierto:** 0 detecciones
- **Inicio:** 0 detecciones

### 💻 **Uso de Recursos del Sistema**
- **Memoria Actual:** `178.82` MB
- **Memoria Promedio:** `169.35` MB
- **CPU Actual:** `0.0%`
- **Posiciones Únicas Visitadas:** 1

### 📈 **Estadísticas de Acciones**
- **Total de Acciones:** 6,991
- **Distribución de Acciones:** {'A': 4003, '↓': 722, '←': 722, '→': 707, '↑': 696, 'B': 141, 'START': 0}

### 🔧 **Configuración del Agente**
- **Algoritmo:** Epsilon Greedy con Heurísticas
- **Epsilon Inicial:** Variable según escenario
- **Tiempo de Entrenamiento:** 0s (sin entrenamiento previo)
- **Versión del Entorno:** Pokemon Red v2

### 📝 **Notas Adicionales**
- Generado automáticamente el 2025-09-20 01:19:19
- Sesión ID: 1758341959
- Razón de finalización: Interrumpido por usuario

---
